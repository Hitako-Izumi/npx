

function App() {

    return (
        <div>
            <div className="press">
                ReactExpress

                <hr/>
                <p className="parraf"><font color="white">Este es una plantilla que incluye a </font> 
                <font color="cyan">React.JS</font> y <font color="#0f0">Express.js </font> 
                para tu proyecto <br/> la plantilla incluye las librerias estandares como <font color="purple">
                    Bootstrap</font> y <font color="yellow">jQuery</font> </p>
                <br/>
                <img src="src/react.png" className="imgs"/>
                <img src="src/express.jpg" className="imgs topi" />
                
            </div>
            <font color="red" className="dofi">
                    depends/js/App/app.js
                </font>
                <p className="titleo">
                   <font color="yellow">CarlosDev (2020)</font> 
                </p>
        </div>
    )
    
}