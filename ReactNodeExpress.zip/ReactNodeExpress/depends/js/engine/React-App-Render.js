//import '../react/react'
//import '../react/react-dom'



ReactDOM.render(
    <App/>,
    document.getElementById("App")
)




