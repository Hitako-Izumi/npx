function require(p) {
    


    document.body.innerHTML += `<script src="/${p}"></script>`
}