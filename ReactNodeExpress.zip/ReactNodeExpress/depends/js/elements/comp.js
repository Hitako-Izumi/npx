import '../react/react'
import '../react/react-dom.min.js'

//console.log("funciona")

