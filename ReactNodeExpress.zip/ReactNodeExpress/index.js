//importar todas las dependencias
const express = require('express');
const app = express();
const bodyparser = require('body-parser')
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');

//configurar para los formularios
app.use(bodyparser.urlencoded( {"extended":true, "limit":false} ));

var datas = {
    "imports": (() => {
        return JSON.parse(fs.readFileSync(path.join(__dirname, "data", "imports.json"), "utf-8"))
    })()
}//datos
var App = {
    "imports": (p) => {

        let dato = datas.imports;
        
        

        for (let i = 0; i < dato.length; i++) {
            const ele = dato[i];

            var salida = "";

            let curret = ele[1].data;

            for (let x = 0; x < curret.length; x++) {
                const elei = curret[x];
                salida = salida + elei;
            };

            p = p.replace(`import:{${ele[0]}}`, salida)    
        };


        return p;
    }
};//herramientas para la App de React
class Pagina {
    constructor(p) {

        this.script = "index";
        this.title = "React App Index";
        this.page = "index"
        

    };
    setTitle(t) {
        this.title = t;
    };
    setScript(s) {
        this.script = s;
    };
    setPage(p) {
        this.title = p;
    };
    
    render() {

        let salida = App.imports(openfile("./public/"+this.page +".html"))
        salida = salida.replace("data:{title}", this.title)
        salida = salida.replace("data:{script}", this.script)

        return salida;
    }
};//clase pagina
function openfile(p) {
    return fs.readFileSync(p, "utf-8")
}


//rutar las dependencias

app.use("/js", express.static(path.join(__dirname, "depends", "js")))
app.use("/src", express.static(path.join(__dirname, "src")))
app.use("/App", express.static(path.join(__dirname, "depends", "js", "App")))
app.use("/css", express.static(path.join(__dirname, "depends", "css")))
app.use("/pb", express.static(path.join(__dirname, "public")))
app.use("/proj", express.static(path.join(__dirname)))
app.get("/React-App", (req, res) => {
    
    res.send(openfile("./depends/js/engine/React-App-Render.js"))

})

//rutar la pagina principal
app.get("/", (req, res) => {

    let mipagina = new Pagina("index")
    mipagina.setTitle("React y Express en uno");
    mipagina.setScript("app")

    
    res.send(mipagina.render());
})


//iniciar el servidor

app.listen(8000, () => {
    console.log("server open in the port 8000")
    //console.log(JSON.stringify(datas))
})
